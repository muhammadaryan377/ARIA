from __future__ import annotations

import re


_IDENTIFIER_HINTS = {
    "id", "key", "code", "number", "no", "phone", "postal", "zip",
    "latitude", "longitude", "year",
}
_BUSINESS_METRIC_HINTS = {
    "sales", "revenue", "amount", "price", "cost", "profit", "margin",
    "discount", "quantity", "qty", "units", "orders", "count", "total",
    "value", "inventory", "stock", "freight", "tax",
}


def _tokens(name: str) -> set[str]:
    return {token for token in re.split(r"[^a-z0-9]+", name.lower()) if token}


def select_metric_columns(numeric_columns: list[str], goal: str | None = None) -> list[str]:
    """Keep numeric business measures while avoiding meaningless analysis of IDs/codes."""
    goal_tokens = _tokens(goal or "")
    scored: list[tuple[float, str]] = []
    for index, column in enumerate(numeric_columns):
        tokens = _tokens(column)
        identifier_like = bool(tokens & _IDENTIFIER_HINTS) and not bool(tokens & _BUSINESS_METRIC_HINTS)
        if identifier_like and not (tokens & goal_tokens):
            continue
        score = 0.0
        score += 4.0 * len(tokens & goal_tokens)
        score += 2.0 * len(tokens & _BUSINESS_METRIC_HINTS)
        score -= index * 0.001  # deterministic stable ordering
        scored.append((score, column))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [column for _, column in scored]
