from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Any


@dataclass(slots=True)
class NormalizedData:
    rows: list[dict[str, Any]]
    goal: str | None
    metadata: dict[str, Any]


def _records_from_columns(columns: list[str], rows: list[Any]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for row in rows:
        if isinstance(row, dict):
            records.append(row)
        elif isinstance(row, (list, tuple)) and len(row) == len(columns):
            records.append(dict(zip(columns, row)))
    return records


def normalize_processed_data(payload: Any) -> NormalizedData:
    """Accept the common Goal-Agent output shapes without coupling to one serializer."""
    goal = None
    metadata: dict[str, Any] = {}

    if isinstance(payload, list):
        rows = [row for row in payload if isinstance(row, dict)]
        return NormalizedData(rows=rows, goal=None, metadata={})

    if not isinstance(payload, dict):
        raise ValueError("processed data must be a dict or a list of records")

    goal = payload.get("goal") or payload.get("user_goal") or payload.get("question")
    metadata = dict(payload.get("metadata") or {})

    candidate = None
    for key in ("rows", "records", "data", "processed_data", "result", "results"):
        value = payload.get(key)
        if isinstance(value, list):
            candidate = value
            break
        if isinstance(value, dict):
            nested = value.get("rows") or value.get("records") or value.get("data")
            if isinstance(nested, list):
                candidate = nested
                metadata.update({k: v for k, v in value.items() if k not in {"rows", "records", "data"}})
                break

    if candidate is None:
        if all(not isinstance(v, (dict, list)) for v in payload.values()):
            candidate = [payload]
        else:
            candidate = []

    columns = payload.get("columns")
    if columns and isinstance(columns, list):
        rows = _records_from_columns([str(c) for c in columns], candidate)
    else:
        rows = [row for row in candidate if isinstance(row, dict)]

    return NormalizedData(rows=rows, goal=goal, metadata=metadata)


def json_safe(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    return value
