from __future__ import annotations

from collections import Counter
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from app.insight_agent.models import DataQuality


NULL_STRINGS = {"", "null", "none", "nan", "n/a", "na"}


def is_missing(value: Any) -> bool:
    return value is None or (isinstance(value, str) and value.strip().lower() in NULL_STRINGS)


def to_number(value: Any) -> float | None:
    if is_missing(value) or isinstance(value, bool):
        return None
    if isinstance(value, (int, float, Decimal)):
        return float(value)
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        if text.startswith("$"):
            text = text[1:]
        try:
            return float(text)
        except ValueError:
            return None
    return None


def to_datetime(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime.combine(value, datetime.min.time())
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip().replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d/%m/%Y", "%Y-%m", "%Y"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


def infer_columns(rows: list[dict[str, Any]]) -> tuple[list[str], list[str], list[str]]:
    if not rows:
        return [], [], []
    columns = sorted({key for row in rows for key in row})
    numeric: list[str] = []
    temporal: list[str] = []
    categorical: list[str] = []

    for column in columns:
        values = [row.get(column) for row in rows if not is_missing(row.get(column))]
        sample = values[:100]
        if not sample:
            categorical.append(column)
            continue
        number_ratio = sum(to_number(v) is not None for v in sample) / len(sample)
        date_ratio = sum(to_datetime(v) is not None for v in sample) / len(sample)
        name = column.lower()
        if date_ratio >= 0.8 and ("date" in name or "time" in name or date_ratio > number_ratio):
            temporal.append(column)
        elif number_ratio >= 0.8:
            numeric.append(column)
        else:
            categorical.append(column)
    return numeric, categorical, temporal


def profile_data(rows: list[dict[str, Any]]) -> DataQuality:
    numeric, categorical, temporal = infer_columns(rows)
    columns = sorted({key for row in rows for key in row})
    missing = {col: sum(is_missing(row.get(col)) for row in rows) for col in columns}

    seen = Counter(tuple(sorted((k, repr(v)) for k, v in row.items())) for row in rows)
    duplicate_rows = sum(count - 1 for count in seen.values() if count > 1)
    warnings: list[str] = []
    if not rows:
        warnings.append("No rows were returned by the Goal Agent.")
    if duplicate_rows:
        warnings.append(f"Detected {duplicate_rows} duplicate row(s).")
    heavily_missing = [col for col, count in missing.items() if rows and count / len(rows) >= 0.5]
    if heavily_missing:
        warnings.append("Columns with >=50% missing values: " + ", ".join(heavily_missing))

    return DataQuality(
        row_count=len(rows),
        column_count=len(columns),
        missing_by_column=missing,
        duplicate_rows=duplicate_rows,
        numeric_columns=numeric,
        categorical_columns=categorical,
        temporal_columns=temporal,
        warnings=warnings,
    )
