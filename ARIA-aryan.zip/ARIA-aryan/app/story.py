from __future__ import annotations

from app.insight_agent.models import DataQuality, Hypothesis, KPI, TrendInsight


def build_business_story(
    quality: DataQuality,
    kpis: list[KPI],
    trends: list[TrendInsight],
    hypotheses: list[Hypothesis],
) -> str:
    if quality.row_count == 0:
        return "No business story was generated because the query returned no rows."

    parts: list[str] = [
        f"ARIA analyzed {quality.row_count:,} row(s) across {quality.column_count} column(s)."
    ]
    if kpis:
        compact = ", ".join(f"{k.name}: {k.formatted_value or k.value}" for k in kpis[:4])
        parts.append(f"Headline measures are {compact}.")
    strong_trends = [t for t in trends if t.direction in {"up", "down"}]
    if strong_trends:
        t = strong_trends[0]
        change = f"{t.percent_change:+.1f}%" if t.percent_change is not None else f"{t.absolute_change:+g}"
        parts.append(
            f"The clearest time signal is {t.metric}, which moved {t.direction} by {change} "
            f"from the first to the last observation (trend confidence {t.confidence:.0%})."
        )
    if hypotheses:
        h = hypotheses[0]
        parts.append(
            f"The highest-ranked explanation to investigate is: {h.title}. "
            f"This is evidence-backed but should not be interpreted as causation without the proposed drill-down."
        )
    if quality.warnings:
        parts.append("Data-quality note: " + " ".join(quality.warnings[:2]))
    return " ".join(parts)
