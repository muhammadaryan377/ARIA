from __future__ import annotations

from app.insight_agent.models import AssociationInsight, ChartSpec, KPI, SegmentInsight, TrendInsight


def recommend_charts(
    kpis: list[KPI],
    trends: list[TrendInsight],
    segments: list[SegmentInsight],
    associations: list[AssociationInsight] | None = None,
    max_charts: int = 6,
) -> list[ChartSpec]:
    charts: list[ChartSpec] = []
    associations = associations or []
    for kpi in kpis[:3]:
        charts.append(ChartSpec(
            id=f"kpi:{kpi.column or kpi.name}",
            chart_type="kpi",
            title=kpi.name,
            y=kpi.column,
            aggregation=kpi.aggregation,
            reason="Fast executive summary of a primary numeric result.",
        ))
    if trends:
        trend = trends[0]
        charts.append(ChartSpec(
            id=f"line:{trend.time_column}:{trend.metric}",
            chart_type="line",
            title=f"{trend.metric.replace('_', ' ').title()} over time",
            x=trend.time_column,
            y=trend.metric,
            reason="A time-series line chart is the clearest view for the detected trend.",
        ))
    for segment in segments[:2]:
        charts.append(ChartSpec(
            id=f"bar:{segment.dimension}:{segment.metric}",
            chart_type="bar",
            title=f"{segment.metric.replace('_', ' ').title()} by {segment.dimension.replace('_', ' ').title()}",
            x=segment.dimension,
            y=segment.metric,
            aggregation="sum",
            sort="desc",
            limit=min(15, segment.segment_count),
            reason="Ranked bars make segment contribution and concentration easy to compare.",
        ))
    if associations:
        association = associations[0]
        charts.append(ChartSpec(
            id=f"scatter:{association.metric_x}:{association.metric_y}",
            chart_type="scatter",
            title=f"{association.metric_y.replace('_', ' ').title()} vs {association.metric_x.replace('_', ' ').title()}",
            x=association.metric_x,
            y=association.metric_y,
            reason="Scatter view validates whether the detected numeric association is broad or driven by a few points.",
        ))
    # Stable de-duplication
    unique = {chart.id: chart for chart in charts}
    return list(unique.values())[:max_charts]
