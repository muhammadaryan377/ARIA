from __future__ import annotations

from app.insight_agent.models import Anomaly, AssociationInsight, Evidence, Hypothesis, SegmentInsight, TrendInsight


def _confidence(score: float) -> str:
    if score >= 0.78:
        return "high"
    if score >= 0.52:
        return "medium"
    return "low"


def generate_hypotheses(
    trends: list[TrendInsight],
    anomalies: list[Anomaly],
    segments: list[SegmentInsight],
    associations: list[AssociationInsight] | None = None,
    max_hypotheses: int = 3,
) -> list[Hypothesis]:
    """Create evidence-grounded hypotheses only from computed signals.

    These are explicitly hypotheses, not causal claims. The next_check field tells the
    Goal Agent / future drill-down what evidence is still needed.
    """
    candidates: list[Hypothesis] = []
    associations = associations or []

    for trend in trends[:2]:
        if trend.direction not in {"up", "down"}:
            continue
        score = min(0.95, 0.55 * trend.confidence + 0.45 * min(1.0, abs(trend.percent_change or 0) / 25))
        direction = "growth" if trend.direction == "up" else "decline"
        candidates.append(Hypothesis(
            id=f"trend:{trend.metric}",
            title=f"Sustained {direction} in {trend.metric}",
            statement=(
                f"{trend.metric} shows a {trend.direction} pattern from {trend.start_value:g} "
                f"to {trend.end_value:g} across {trend.observations} ordered observations. "
                "This may represent a persistent shift rather than a one-off movement."
            ),
            score=round(score, 3),
            confidence=_confidence(score),
            status="supported" if trend.r_squared >= 0.5 else "plausible",
            evidence=[Evidence(
                kind="trend",
                metric=trend.metric,
                value=trend.end_value,
                baseline=trend.start_value,
                delta=trend.percent_change,
                note=f"R²={trend.r_squared:.2f}; confidence={trend.confidence:.2f}",
            )],
            next_check=f"Break {trend.metric} down by product/category/region/customer dimensions to locate the driver.",
        ))

    for segment in segments[:2]:
        share = segment.top_share or 0.0
        score = min(0.93, 0.45 + min(0.40, share / 100 * 0.5) + (0.08 if segment.segment_count >= 4 else 0))
        candidates.append(Hypothesis(
            id=f"segment:{segment.dimension}:{segment.metric}",
            title=f"{segment.metric} is concentrated in {segment.top_segment}",
            statement=(
                f"{segment.top_segment} is the leading {segment.dimension} segment for {segment.metric} "
                f"with {segment.top_value:g}"
                + (f" ({share:.1f}% of the observed total)." if segment.top_share is not None else ".")
                + " This concentration could be materially influencing the overall result."
            ),
            score=round(score, 3),
            confidence=_confidence(score),
            status="supported",
            evidence=[Evidence(
                kind="segment_contribution",
                metric=segment.metric,
                dimension=segment.dimension,
                value=segment.top_value,
                baseline=segment.bottom_value,
                delta=segment.top_share,
                note=f"Top-3 concentration={segment.concentration_top3}%" if segment.concentration_top3 is not None else None,
            )],
            next_check=f"Compare {segment.top_segment} with peer {segment.dimension} segments over time and on volume, price, discount, and margin drivers where available.",
        ))


    for association in associations[:2]:
        magnitude = abs(association.correlation)
        score = min(0.88, 0.48 + 0.40 * magnitude)
        candidates.append(Hypothesis(
            id=f"association:{association.metric_x}:{association.metric_y}",
            title=f"{association.metric_x} and {association.metric_y} move together",
            statement=(
                f"{association.metric_x} and {association.metric_y} show a {association.strength} "
                f"{association.direction} association (r={association.correlation:.2f}, "
                f"n={association.observations}). This is useful for investigation but does not establish causality."
            ),
            score=round(score, 3),
            confidence=_confidence(score),
            status="plausible",
            evidence=[Evidence(
                kind="association",
                metric=association.metric_x,
                dimension=association.metric_y,
                value=association.correlation,
                note=f"Pearson correlation over {association.observations} paired observations",
            )],
            next_check=f"Control for time and major segments, then test whether changes in {association.metric_y} precede or explain changes in {association.metric_x}.",
        ))

    if anomalies:
        anomaly = anomalies[0]
        score = min(0.9, 0.5 + min(0.35, anomaly.score / 15))
        candidates.append(Hypothesis(
            id=f"anomaly:{anomaly.metric}:{anomaly.row_index}",
            title=f"Unusual {anomaly.metric} observation may distort the result",
            statement=(
                f"Row {anomaly.row_index} has an unusual {anomaly.metric} value of {anomaly.value:g} "
                f"with anomaly score {anomaly.score:.2f}. It should be validated before treating aggregate movement as normal business behavior."
            ),
            score=round(score, 3),
            confidence=_confidence(score),
            status="supported",
            evidence=[Evidence(
                kind="anomaly",
                metric=anomaly.metric,
                value=anomaly.value,
                row_indices=[anomaly.row_index],
                note=f"Method={anomaly.method}; score={anomaly.score:.2f}",
            )],
            next_check="Inspect the underlying transaction/entity and compare it with neighboring observations to determine whether it is valid business activity or a data-quality issue.",
        ))

    ranked = sorted(candidates, key=lambda h: h.score, reverse=True)[:max_hypotheses]
    for rank, hypothesis in enumerate(ranked, start=1):
        hypothesis.rank = rank
    return ranked
