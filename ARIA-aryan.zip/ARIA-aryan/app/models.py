from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class Evidence(BaseModel):
    kind: str
    metric: str | None = None
    dimension: str | None = None
    value: Any = None
    baseline: Any = None
    delta: float | None = None
    row_indices: list[int] = Field(default_factory=list)
    note: str | None = None


class KPI(BaseModel):
    name: str
    column: str | None = None
    value: float | int | str | None = None
    aggregation: str
    formatted_value: str | None = None
    confidence: float = 1.0


class TrendInsight(BaseModel):
    metric: str
    time_column: str
    direction: Literal["up", "down", "flat", "mixed"]
    start_value: float
    end_value: float
    absolute_change: float
    percent_change: float | None = None
    slope: float = 0.0
    r_squared: float = 0.0
    observations: int
    confidence: float = 0.0


class Anomaly(BaseModel):
    metric: str
    row_index: int
    value: float
    score: float
    method: str
    context: dict[str, Any] = Field(default_factory=dict)


class AssociationInsight(BaseModel):
    metric_x: str
    metric_y: str
    correlation: float
    strength: Literal["strong", "moderate", "weak"]
    direction: Literal["positive", "negative"]
    observations: int


class SegmentInsight(BaseModel):
    dimension: str
    metric: str
    top_segment: str
    top_value: float
    top_share: float | None = None
    bottom_segment: str | None = None
    bottom_value: float | None = None
    segment_count: int
    concentration_top3: float | None = None


class Hypothesis(BaseModel):
    id: str
    title: str
    statement: str
    rank: int = 0
    score: float = 0.0
    confidence: Literal["high", "medium", "low"] = "low"
    status: Literal["supported", "plausible", "insufficient_evidence"] = "plausible"
    evidence: list[Evidence] = Field(default_factory=list)
    next_check: str | None = None


class ChartSpec(BaseModel):
    id: str
    chart_type: Literal["kpi", "line", "bar", "scatter", "table"]
    title: str
    x: str | None = None
    y: str | None = None
    aggregation: str | None = None
    sort: str | None = None
    limit: int | None = None
    reason: str


class DataQuality(BaseModel):
    row_count: int
    column_count: int
    missing_by_column: dict[str, int] = Field(default_factory=dict)
    duplicate_rows: int = 0
    numeric_columns: list[str] = Field(default_factory=list)
    categorical_columns: list[str] = Field(default_factory=list)
    temporal_columns: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class InsightReport(BaseModel):
    version: str = "1.0"
    goal: str | None = None
    generated_from_rows: int
    data_quality: DataQuality
    kpis: list[KPI] = Field(default_factory=list)
    trends: list[TrendInsight] = Field(default_factory=list)
    anomalies: list[Anomaly] = Field(default_factory=list)
    segments: list[SegmentInsight] = Field(default_factory=list)
    associations: list[AssociationInsight] = Field(default_factory=list)
    hypotheses: list[Hypothesis] = Field(default_factory=list)
    charts: list[ChartSpec] = Field(default_factory=list)
    story: str = ""
    limitations: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
