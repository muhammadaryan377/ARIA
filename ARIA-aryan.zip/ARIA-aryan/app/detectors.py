from __future__ import annotations

from collections import defaultdict
from math import sqrt
from statistics import median
from typing import Any

from app.insight_agent.models import Anomaly, KPI, SegmentInsight, TrendInsight
from app.insight_agent.profiling import to_datetime, to_number


def _format_number(value: float) -> str:
    abs_value = abs(value)
    if abs_value >= 1_000_000_000:
        return f"{value / 1_000_000_000:.2f}B"
    if abs_value >= 1_000_000:
        return f"{value / 1_000_000:.2f}M"
    if abs_value >= 1_000:
        return f"{value / 1_000:.2f}K"
    return f"{value:,.2f}".rstrip("0").rstrip(".")


def compute_kpis(rows: list[dict[str, Any]], numeric_columns: list[str], max_kpis: int = 8) -> list[KPI]:
    kpis: list[KPI] = [KPI(name="Rows", value=len(rows), aggregation="count", formatted_value=f"{len(rows):,}")]
    for column in numeric_columns[:max_kpis - 1]:
        values = [n for row in rows if (n := to_number(row.get(column))) is not None]
        if not values:
            continue
        total = sum(values)
        # Keep both total and average semantically available, but surface a single compact KPI.
        aggregation = "sum" if len(values) > 1 else "value"
        value = total if aggregation == "sum" else values[0]
        kpis.append(KPI(
            name=column.replace("_", " ").title(),
            column=column,
            value=round(value, 4),
            aggregation=aggregation,
            formatted_value=_format_number(value),
            confidence=1.0,
        ))
    return kpis


def _linear_regression(values: list[float]) -> tuple[float, float]:
    n = len(values)
    if n < 2:
        return 0.0, 0.0
    xs = list(range(n))
    x_bar = (n - 1) / 2
    y_bar = sum(values) / n
    ss_x = sum((x - x_bar) ** 2 for x in xs)
    if ss_x == 0:
        return 0.0, 0.0
    slope = sum((x - x_bar) * (y - y_bar) for x, y in zip(xs, values)) / ss_x
    predicted = [y_bar + slope * (x - x_bar) for x in xs]
    ss_tot = sum((y - y_bar) ** 2 for y in values)
    ss_res = sum((y - p) ** 2 for y, p in zip(values, predicted))
    r2 = 1 - (ss_res / ss_tot) if ss_tot else 1.0
    return slope, max(0.0, min(1.0, r2))


def detect_trends(
    rows: list[dict[str, Any]],
    numeric_columns: list[str],
    temporal_columns: list[str],
    max_trends: int = 5,
) -> list[TrendInsight]:
    if not temporal_columns:
        return []
    time_col = temporal_columns[0]
    trends: list[TrendInsight] = []

    for metric in numeric_columns:
        points = []
        for row in rows:
            dt = to_datetime(row.get(time_col))
            value = to_number(row.get(metric))
            if dt is not None and value is not None:
                points.append((dt, value))
        if len(points) < 3:
            continue
        points.sort(key=lambda item: item[0])
        values = [item[1] for item in points]
        start, end = values[0], values[-1]
        change = end - start
        pct = (change / abs(start) * 100) if start != 0 else None
        slope, r2 = _linear_regression(values)
        scale = max(abs(sum(values) / len(values)), 1e-9)
        normalized_slope = slope / scale
        if abs(normalized_slope) < 0.005 or abs(change) < scale * 0.02:
            direction = "flat"
        elif r2 < 0.15:
            direction = "mixed"
        else:
            direction = "up" if change > 0 else "down"
        confidence = min(0.99, 0.35 + 0.45 * r2 + 0.20 * min(1.0, len(values) / 12))
        trends.append(TrendInsight(
            metric=metric,
            time_column=time_col,
            direction=direction,
            start_value=round(start, 4),
            end_value=round(end, 4),
            absolute_change=round(change, 4),
            percent_change=round(pct, 2) if pct is not None else None,
            slope=round(slope, 6),
            r_squared=round(r2, 4),
            observations=len(values),
            confidence=round(confidence, 3),
        ))
    return sorted(trends, key=lambda t: (t.confidence, abs(t.percent_change or 0)), reverse=True)[:max_trends]


def detect_anomalies(
    rows: list[dict[str, Any]],
    numeric_columns: list[str],
    max_anomalies: int = 10,
    threshold: float = 3.5,
) -> list[Anomaly]:
    anomalies: list[Anomaly] = []
    for metric in numeric_columns:
        indexed = [(idx, n) for idx, row in enumerate(rows) if (n := to_number(row.get(metric))) is not None]
        values = [v for _, v in indexed]
        if len(values) < 5:
            continue
        med = median(values)
        deviations = [abs(v - med) for v in values]
        mad = median(deviations)
        if mad == 0:
            mean = sum(values) / len(values)
            variance = sum((v - mean) ** 2 for v in values) / len(values)
            stdev = sqrt(variance)
            if stdev == 0:
                continue
            scored = [(idx, value, abs(value - mean) / stdev, "zscore") for idx, value in indexed]
        else:
            scored = [(idx, value, 0.6745 * abs(value - med) / mad, "modified_zscore") for idx, value in indexed]
        for idx, value, score, method in scored:
            if score >= threshold:
                context = {k: v for k, v in rows[idx].items() if k != metric}
                anomalies.append(Anomaly(
                    metric=metric,
                    row_index=idx,
                    value=round(value, 4),
                    score=round(score, 3),
                    method=method,
                    context=dict(list(context.items())[:5]),
                ))
    return sorted(anomalies, key=lambda item: item.score, reverse=True)[:max_anomalies]


def analyze_segments(
    rows: list[dict[str, Any]],
    numeric_columns: list[str],
    categorical_columns: list[str],
    max_segments: int = 6,
) -> list[SegmentInsight]:
    insights: list[SegmentInsight] = []
    for dimension in categorical_columns:
        unique = {str(row.get(dimension)) for row in rows if row.get(dimension) is not None}
        if not (2 <= len(unique) <= 50):
            continue
        for metric in numeric_columns:
            grouped: dict[str, float] = defaultdict(float)
            for row in rows:
                number = to_number(row.get(metric))
                segment = row.get(dimension)
                if number is not None and segment is not None:
                    grouped[str(segment)] += number
            if len(grouped) < 2:
                continue
            ranked = sorted(grouped.items(), key=lambda item: item[1], reverse=True)
            total = sum(v for _, v in ranked)
            top_name, top_value = ranked[0]
            bottom_name, bottom_value = ranked[-1]
            top_share = (top_value / total * 100) if total else None
            top3 = (sum(v for _, v in ranked[:3]) / total * 100) if total else None
            insights.append(SegmentInsight(
                dimension=dimension,
                metric=metric,
                top_segment=top_name,
                top_value=round(top_value, 4),
                top_share=round(top_share, 2) if top_share is not None else None,
                bottom_segment=bottom_name,
                bottom_value=round(bottom_value, 4),
                segment_count=len(ranked),
                concentration_top3=round(top3, 2) if top3 is not None else None,
            ))
    return sorted(insights, key=lambda s: (s.top_share or 0, s.segment_count), reverse=True)[:max_segments]


def detect_associations(
    rows: list[dict[str, Any]],
    numeric_columns: list[str],
    max_associations: int = 5,
) -> list:
    from app.insight_agent.models import AssociationInsight

    results: list[AssociationInsight] = []
    for i, x_col in enumerate(numeric_columns):
        for y_col in numeric_columns[i + 1:]:
            pairs = []
            for row in rows:
                x = to_number(row.get(x_col))
                y = to_number(row.get(y_col))
                if x is not None and y is not None:
                    pairs.append((x, y))
            if len(pairs) < 6:
                continue
            xs = [x for x, _ in pairs]
            ys = [y for _, y in pairs]
            x_mean = sum(xs) / len(xs)
            y_mean = sum(ys) / len(ys)
            numerator = sum((x - x_mean) * (y - y_mean) for x, y in pairs)
            x_ss = sum((x - x_mean) ** 2 for x in xs)
            y_ss = sum((y - y_mean) ** 2 for y in ys)
            denominator = sqrt(x_ss * y_ss)
            if denominator == 0:
                continue
            corr = max(-1.0, min(1.0, numerator / denominator))
            magnitude = abs(corr)
            if magnitude < 0.5:
                continue
            strength = "strong" if magnitude >= 0.75 else "moderate"
            results.append(AssociationInsight(
                metric_x=x_col,
                metric_y=y_col,
                correlation=round(corr, 4),
                strength=strength,
                direction="positive" if corr > 0 else "negative",
                observations=len(pairs),
            ))
    return sorted(results, key=lambda item: abs(item.correlation), reverse=True)[:max_associations]
