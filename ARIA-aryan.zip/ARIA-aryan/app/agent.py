from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from app.insight_agent.detectors import (
    analyze_segments,
    compute_kpis,
    detect_anomalies,
    detect_associations,
    detect_trends,
)
from app.insight_agent.hypotheses import generate_hypotheses
from app.insight_agent.metrics import select_metric_columns
from app.insight_agent.models import InsightReport
from app.insight_agent.normalizer import json_safe, normalize_processed_data
from app.insight_agent.profiling import profile_data
from app.insight_agent.story import build_business_story
from app.insight_agent.visuals import recommend_charts

logger = logging.getLogger(__name__)


class InsightAgent:
    """Evidence-first BI insight engine.

    The agent deliberately keeps signal detection deterministic. An LLM can narrate
    or rephrase later, but it should never invent KPIs, trends, anomalies, or causes.
    This makes the output testable, reproducible, and safe to feed into the feedback
    agent for ranking/model improvement.
    """

    def __init__(
        self,
        output_directory: str = "data/insights",
        max_hypotheses: int = 3,
        max_anomalies: int = 10,
    ) -> None:
        self.output_directory = Path(output_directory)
        self.output_directory.mkdir(parents=True, exist_ok=True)
        self.max_hypotheses = max_hypotheses
        self.max_anomalies = max_anomalies

    def run(self, processed_data: dict[str, Any] | list[dict[str, Any]], goal: str | None = None) -> InsightReport:
        logger.info("Insight Agent started")
        normalized = normalize_processed_data(processed_data)
        rows = normalized.rows
        resolved_goal = goal or normalized.goal

        quality = profile_data(rows)
        metric_columns = select_metric_columns(quality.numeric_columns, resolved_goal)
        kpis = compute_kpis(rows, metric_columns)
        trends = detect_trends(rows, metric_columns, quality.temporal_columns)
        anomalies = detect_anomalies(rows, metric_columns, max_anomalies=self.max_anomalies)
        segments = analyze_segments(rows, metric_columns, quality.categorical_columns)
        associations = detect_associations(rows, metric_columns)
        hypotheses = generate_hypotheses(
            trends=trends,
            anomalies=anomalies,
            segments=segments,
            associations=associations,
            max_hypotheses=self.max_hypotheses,
        )
        charts = recommend_charts(kpis=kpis, trends=trends, segments=segments, associations=associations)
        story = build_business_story(quality, kpis, trends, hypotheses)

        limitations: list[str] = [
            "Hypotheses indicate patterns to investigate; they are not causal conclusions.",
            "The agent only reasons from fields and rows returned by the Goal Agent.",
        ]
        if not quality.temporal_columns:
            limitations.append("No reliable temporal column was detected, so time-trend analysis was skipped.")
        if len(rows) < 5:
            limitations.append("The result set is small; anomaly and distribution signals may be weak.")

        report = InsightReport(
            goal=resolved_goal,
            generated_from_rows=len(rows),
            data_quality=quality,
            kpis=kpis,
            trends=trends,
            anomalies=anomalies,
            segments=segments,
            associations=associations,
            hypotheses=hypotheses,
            charts=charts,
            story=story,
            limitations=limitations,
            metadata={
                **normalized.metadata,
                "analysis_policy": "deterministic_evidence_first",
                "analyzed_metric_columns": metric_columns,
                "hypothesis_count": len(hypotheses),
            },
        )
        logger.info(
            "Insight Agent completed: rows=%d trends=%d anomalies=%d hypotheses=%d",
            len(rows), len(trends), len(anomalies), len(hypotheses),
        )
        return report

    def run_file(self, input_path: str | Path, output_filename: str = "insights_output.json", goal: str | None = None) -> InsightReport:
        input_path = Path(input_path)
        with input_path.open("r", encoding="utf-8") as file:
            payload = json.load(file)
        report = self.run(payload, goal=goal)
        self.save(report, output_filename)
        return report

    def save(self, report: InsightReport, filename: str = "insights_output.json") -> Path:
        output_path = self.output_directory / filename
        payload = json_safe(report.model_dump(mode="python"))
        with output_path.open("w", encoding="utf-8") as file:
            json.dump(payload, file, indent=2, ensure_ascii=False)
        logger.info("Insight report saved to: %s", output_path)
        return output_path
